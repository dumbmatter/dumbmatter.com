clear all; close all;

hh_circ = importdata('params/hh_circ.txt');

%% Fig 2: No LPS
figure;
run_model(1, 0, 96, hh_circ);

%% Fig 5: LPS=10; midnight -> unresolved inflammation,  8am -> resolved inflammation
figure;
run_model(1, 10, 96+8, hh_circ, '--');
run_model(1, 10, 96, hh_circ);

%% Fig 6: LPS=1, 8pm -> melatonin levels are suppressed
figure;
run_model(1, 0, 0, hh_circ, '--');
run_model(1, 1, 96+12+8, hh_circ);