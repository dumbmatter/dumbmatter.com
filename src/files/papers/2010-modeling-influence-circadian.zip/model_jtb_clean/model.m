function [dy] = model(t, y, tlps, hh_circ, hh_lps, hh_fen, hhall, hh_sig, hh, hh_jusko)

%% Read input

% LPS recognition
LPS = y(1);
mRNA_R = y(4);
R = y(5); % Toll-like receptor 4
LPSR = y(2);

% NFkB regulation
IKK = y(3);
mRNA_IkBa = y(7);
IkBa = y(8);
NFkBn = y(6);

% Intrinsic responses
P = y(9); % Pro-inflammatory response
A = y(10); % Anti-inflammatory response
E = y(11); % Energetic response

% Epinephrine signaling
EPI = y(12);
R_EPI = y(22); % Epinephrine receptor
EPIR = y(23);
cAMP = y(13);

% HRV
HRV = y(14);

% Corticosteroid signaling
F = y(17);
mRNA_R_F = y(18);
R_F = y(19); % Glucocorticoid receptor
FR = y(20);
FRn = y(21);

% Melatonin
MEL = y(15);
if t<tlps
    LPS = 0; % LPS = 0 (NO INFLAMMATORY STIMULUS)
end

%% Differential equations

% LPS recognition
dLPS= hh(1,1)*LPS*(1-LPS) - hh(2,1)*LPS;
dmRNA_R = hh(8,1)*(1 + hh(9,1)*P) - hh(10,1)*mRNA_R;
dR = hh(3,1)*mRNA_R + hh(4,1)*LPSR- hh(5,1)*LPS*R - hh(3,1)*R;
dLPSR = hh(5,1)*LPS*R - hh(6,1)*LPSR - hh(4,1)*LPSR;

% NFkB regulation
dIKK = hh(6,1)*LPSR/(1+IkBa) - hh(7,1)*IKK + P*(IKK^2)/(1+IKK^2);
dmRNA_IkBa = hh(13,1)*(1+hh(14,1)*NFkBn) - hh(15,1)*mRNA_IkBa;
dIkBa = hh(16,1)*mRNA_IkBa - hh(17,1)*(1+IKK)*IkBa*(1-NFkBn) - hh(16,1);     
dNFkBn = (hh(11,1)*IKK*(1-NFkBn))/(1+IkBa)-hh(12,1)*NFkBn*IkBa;

% Intrinsic responses
dP = hh(18,1)*(1+hh(19,1)*NFkBn)*(1+hh(20,1)*E)*(1+hh_circ(6)*MEL)/A - hh(21,1)*P;
dA = hh_lps(1,1)*(1+hh_lps(2,1)*cAMP)*(1+hh_lps(3,1)*E)*(1+hh_lps(5,1)*FRn)*(1+hh_circ(7)*MEL) - hh_lps(4,1)*A;
dE = hh(26,1)*(1+hh(27,1)*P)/A - hh(28,1)*E;

% Epinephrine signaling
dEPI = hhall(1,1)*(1+hhall(2,1)*P)*(1+hh_circ(5)*FRn) - hhall(3,1)*EPI;
dR_EPI = hhall(5,1) - hhall(6,1)*R_EPI*(1+hhall(7,1)*EPI) - hhall(8,1)*R_EPI;
dEPIR = hhall(6,1)*R_EPI*(1+hhall(7,1)*EPI) - hhall(9,1)*(EPIR+1);
dcAMP = (1/hhall(10,1))*((1+EPIR)^hhall(11,1) - cAMP); % Typo in JTB paper
   
% HRV
dHRV = hh_sig(10,1)/EPI - hh_sig(9,1)*HRV;

% Corticosteroid signaling
if (mod(t-hh_circ(8),24) > hh_circ(9))
    Prod_F = hh_circ(4);
else
    Prod_F = 0;
end
dF = Prod_F + hh_fen(1,1)*(1+hh_fen(2,1)*P) - hh_fen(3,1)*F;    
dmRNA_R_F = hh_jusko(1,1)*(1 - (FRn/(hh_jusko(2,1)+FRn))) - hh_jusko(3,1)*mRNA_R_F;
dR_F = hh_jusko(4,1)*mRNA_R_F + hh_jusko(5,1)*hh_jusko(6,1)*FRn - hh_jusko(7,1)*(F-1)*R_F - hh_jusko(12,1)*R_F;
dFR = hh_jusko(7,1)*(F-1)*R_F - hh_jusko(13,1)*FR; % Typo in JTB paper
dFRn = hh_jusko(13,1)*FR - hh_jusko(6,1)*FRn;

% Melatonin
if (mod(t-hh_circ(10), 24) > hh_circ(11))
    Prod_MEL = hh_circ(1);
else
    Prod_MEL = hh_circ(2);
end
dMEL = Prod_MEL*(1-P/(1+P))*(1+F/(1+F)) - hh_circ(3)*MEL;

%% Format output

dy = zeros(size(y));

% LPS recognition
dy(1) = dLPS;
dy(4) = dmRNA_R;
dy(5) = dR;
dy(2) = dLPSR;

% NFkB regulation
dy(3) = dIKK;
dy(7) = dmRNA_IkBa;
dy(8) = dIkBa;
dy(6) = dNFkBn;

% Intrinsic responses
dy(9) = dP;
dy(10) = dA;
dy(11) = dE;

% Epinephrine signaling
dy(12) = dEPI;
dy(22) = dR_EPI;
dy(23) = dEPIR;
dy(13) = dcAMP;

% HRV
dy(16) = 0;
dy(14) = dHRV;

% Corticosteroid signaling
dy(17) = dF;
dy(18) = dmRNA_R_F;
dy(19) = dR_F;
dy(20) = dFR;
dy(21) = dFRn;

% Melatonin
dy(15) = dMEL;
