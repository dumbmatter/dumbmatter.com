function plot_variable(t, y, t_cutoff, norm_y, min_y, line_style, color)
% t: Time vector from the model
% y: Variable from the model
% data_t: Time vector for real data (Optional)
% data_y: Real data (Optional)
% t_cutoff: Where to start plotting t (Optional; default is 48)
% norm_y, min_y: If input > 0, use this to normalize the curves

if nargin<=2
    t_cutoff = 48;
end
if nargin<=3
    norm_y = 0;
end
if nargin<=4
    min_y = 0;
end
if nargin<=5
    line_style = '';
end
if nargin<=6
    color = 'k';
end

% Plot y vs. t, scaled to go from 0 to 1.
hold on;
plot(t(t>t_cutoff)-t_cutoff,(y(t>t_cutoff)-min_y)/norm_y, sprintf('%s%s', color, line_style), 'LineWidth', 2)

% y-axis scaling
ys = (y(t>t_cutoff)'-min_y)/norm_y;
y0 = min(ys);
y1 = max(ys);
ylim([y0-0.1*(y1-y0), y1+0.1*(y1-y0)]);
