This is an implementation of the model from the paper:

Scheff JD, Calvano SE, Lowry SF, Androulakis IP: Modeling the influence of
  circadian rhythms on the acute inflammatory response. J Theor Biol 2010,
  in press. doi:10.1016/j.jtbi.2010.03.026

All code is copyright (C) 2010 Jeremy Scheff <jdscheff@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

---

Main files:
model.m: model equations
run_model.m: function that runs everything and makes plots
test_model.m: generates the plots shown in the paper

The code should run on any recent version of MATLAB (I used R2009a).

NOTE: Some of the parameters in the files in the params folder are not
actually used by this model, but I left them there so that the parameter
files are identical to those of the prior model made by our lab that does
not include any circadian variability.
