function [t, y] = run_model(make_plots, LPS, t_LPS, hh_circ, line_style, hh_lps, hh_fen, hhall, hh_sig, hh, hh_jusko)

% If not specified, use the default line style
if nargin<=4
    line_style = '';
end

y1_0 = LPS; % LPS(t=0h) INFLAMMATORY STIMULUS 

tlps = t_LPS;
tfinal = 200; % Integrate until t=tfinal
t_cutoff = 96; % Where to start plotting

% IMPORT PARAMETER VECTORS for ODE model if they are not passed
if nargin<=5
    hh_lps = importdata('params/hh_lps.txt');
    hh_fen = importdata('params/hh_fen.txt');
    hhall = importdata('params/hh_all.txt');
    hh_sig = importdata('params/hh_sig.txt');
    hh = importdata('params/hh.txt');
    hh_jusko = importdata('params/hh_jusko.txt');
end

y0 = [y1_0 0 0 1 1 0 1 0 1 1 1 1 1 1 0 0 1 25.8 540.7 0 0 1 0]; % Initial condition vector - shouldn't matter much
options = odeset('Nonnegative', [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23]);

[t, y] = ode45(@model, [0, tfinal], y0, options, tlps, hh_circ, hh_lps, hh_fen, hhall, hh_sig, hh, hh_jusko); 

% PLOTTING
if make_plots
    % NORMALIZATION
    % These are from the no LPS condition.
    norm_y = [0.9392    0.1486    0.4107    0.2105    0.5402    0.0262];
    min_y = [0.9698    0.8290    1.0139    0.9739    0.0602    0.9459];

    subplot(3,2,1);
    plot_variable(t, y(:,17), t_cutoff, norm_y(1), min_y(1), line_style);
    ylabel('Cortisol');

    subplot(3,2,3);
    plot_variable(t, y(:,9), t_cutoff, norm_y(2), min_y(2), line_style, 'r');
    ylabel('P');

    subplot(3,2,4);
    plot_variable(t, y(:,10), t_cutoff, norm_y(3), min_y(3), line_style, 'g');
    ylabel('A');

    subplot(3,2,5);
    plot_variable(t, y(:,12), t_cutoff, norm_y(4), min_y(4), line_style);
    ylabel('Epinephrine');

    subplot(3,2,2);
    plot_variable(t, y(:,15), t_cutoff, norm_y(5), min_y(5), line_style);
    ylabel('Melatonin');

    subplot(3,2,6);
    plot_variable(t, y(:,14), t_cutoff, norm_y(6), min_y(6), line_style);
    ylabel('HRV');

    % Style the plots
    for i=1:6
        subplot(3,2,i);
        set(gca, 'XTick', [0, 24, 48, 72, 96]);
        set(gca, 'XTickLabel', {'12am'})
        xlim([0, 48]); % This should probably be set somewhere earlier..
        grid on;
    end
end
